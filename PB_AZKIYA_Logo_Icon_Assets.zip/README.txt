PB AZKIYA launcher icon assets

Copy the folders in this package into:
PB_AZKIYA_Android/app/src/main/res/

If AndroidManifest.xml already uses @mipmap/ic_launcher, no manifest change is needed.
If it uses a different icon resource name, update android:icon to @mipmap/ic_launcher.
Then rebuild the APK with the existing GitHub Actions workflow.
