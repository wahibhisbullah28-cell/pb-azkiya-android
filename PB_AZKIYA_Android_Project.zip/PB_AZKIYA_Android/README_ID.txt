PB AZKIYA - APLIKASI ANDROID

Aplikasi ini membungkus website PB AZKIYA yang sudah ada dalam Android WebView.
Website tetap menjadi sumber tampilan dan sistem backend tetap menggunakan Google Apps Script, Google Sheets, serta Fonnte.

URL website: https://azkiya-badminton.netlify.app/
Application ID: net.azkiya.pb
Versi: 1.0.0

MEMBUAT APK DENGAN ANDROID STUDIO
1. Ekstrak folder PB_AZKIYA_Android.
2. Buka Android Studio, pilih Open, lalu pilih folder PB_AZKIYA_Android.
3. Tunggu Gradle Sync dan pemasangan Android SDK 35 jika diminta.
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK debug tersedia di app/build/outputs/apk/debug/app-debug.apk.

MEMBUAT APK MELALUI GITHUB (TANPA ANDROID STUDIO DI KOMPUTER)
1. Buat repository GitHub baru dan unggah seluruh isi folder ini.
2. Buka tab Actions.
3. Jalankan workflow Build PB AZKIYA APK (atau tunggu build otomatis setelah push ke main).
4. Setelah selesai, unduh artifact bernama PB-AZKIYA-APK.
5. Ekstrak artifact untuk memperoleh app-debug.apk.

CATATAN
- Perlu internet untuk membuka aplikasi.
- Fitur unggah foto menggunakan pemilih file Android.
- Unduhan file/PDF diteruskan ke Download Manager Android.
- Tautan eksternal seperti WhatsApp dibuka melalui aplikasi yang sesuai jika tersedia.
- APK ini belum ditandatangani sebagai rilis Play Store. Untuk distribusi internal, debug APK dapat dipasang dengan mengizinkan instalasi dari sumber yang dipilih.
- Jangan memasukkan token Fonnte ke dalam aplikasi; token tetap disimpan di Script Properties Google Apps Script.
